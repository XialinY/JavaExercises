package at.technikum.ExamExercise.CarWorkshop;

public class Audi extends Car{
    public Audi(int year) {
        super(year);
    }

    @Override
    public String toString() {
        return "Audi";
    }
}
