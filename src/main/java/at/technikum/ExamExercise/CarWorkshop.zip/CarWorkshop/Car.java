package at.technikum.ExamExercise.CarWorkshop;

public abstract class Car {

    protected int year;

    public Car (int year) {
        this.year = year;
    }
}
