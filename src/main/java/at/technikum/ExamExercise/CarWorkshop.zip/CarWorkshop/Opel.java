package at.technikum.ExamExercise.CarWorkshop;

public class Opel extends Car{
    public Opel(int year) {
        super(year);
    }

    @Override
    public String toString() {
        return "Opel";
    }
}
