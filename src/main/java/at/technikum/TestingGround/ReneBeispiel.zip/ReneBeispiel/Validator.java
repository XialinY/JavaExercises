package at.technikum.TestingGround.ReneBeispiel;

public interface Validator {

    boolean validate(String code);
}
