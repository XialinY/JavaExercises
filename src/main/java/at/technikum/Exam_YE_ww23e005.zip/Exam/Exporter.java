package at.technikum.Exam;

public interface Exporter {
    void export(Course course);
}
